package com.brillio.unified_portal_onboarding_updated;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnifiedPortalOnboardingUpdatedApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnifiedPortalOnboardingUpdatedApplication.class, args);
	}

}
