package com.brillio.unified_portal_onboarding_updated;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnifiedPortalOnboardingUpdatedApplicationTests {

	@Test
	void contextLoads() {
	}

}
